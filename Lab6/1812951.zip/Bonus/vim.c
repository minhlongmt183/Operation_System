#include <stdio.h>

int main(int agrc, char *argv[]){
	printf("hello world!\n");
	return 0;
}
